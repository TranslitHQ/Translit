// Run bookmarklet.js through ShrinkSafe, prepend javascript:, and encodeURI.

(function(callback, win) {
  if(!win) {
    win = window;
  }
  var c, frame;
  var iframes = document.getElementsByTagName('iframe');
  for(c = 0; frame = iframes[c]; c++) {
    // use setTimeout 0 so exceptions don't kill the loop
    setTimeout(arguments.callee, 0, callback, frame);  
  }
  if(win.frames.length) {
    for(c = 0; frame = win.frames[c]; c++) {
      setTimeout(arguments.callee, 0, callback, frame);
    }
  } else {
    callback(win);
  }
})(function() {
