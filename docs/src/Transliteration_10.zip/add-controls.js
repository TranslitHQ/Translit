var result = document.evaluate('//input[not(@type) or @type="text"] | //textarea', document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
for(var c = 0; input = result.snapshotItem(c); c++) {
  var translit = new Transliterator(input);
  translit.enable();
  var frag = document.createDocumentFragment();
  frag.appendChild(document.createTextNode(' ['));
  var enableLink = document.createElement('a');
  enableLink.href = 'javascript:;';
  enableLink.appendChild(document.createTextNode('cyr'));
  enableLink.addEventListener('click', bind(translit.enable, translit), false);
  frag.appendChild(enableLink);
  frag.appendChild(document.createTextNode(' / '));
  var disableLink = document.createElement('a');
  disableLink.href = 'javascript:;';
  disableLink.appendChild(document.createTextNode('lat'));
  disableLink.addEventListener('click', bind(translit.disable, translit), false);
  frag.appendChild(disableLink);
  frag.appendChild(document.createTextNode('] '));
  input.parentNode.insertBefore(frag, input.nextSibling);
}
