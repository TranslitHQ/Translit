// ==UserScript==
// @name          Latin-Cyrillic (English-Russian) Transliteration Tool
// @namespace     tag:domnit.org:2006-11-29,translit
// @description   Add controls to every text input to enter either normal Latin text, such as English, or to transliterate to Cyrillic, such as Russian. IT IS ADVISED THAT YOU CHANGE THE INCLUDE SETTING FROM THE GREASEMONKEY SCRIPT MANAGER.
// ==/UserScript==
