#!/bin/sh

# GM script
cat gmscript-header.js COPYING translit.js add-controls.js > translit.user.js

# Bookmarklet
cat bookmarklet-header.js translit.js add-controls.js bookmarklet-footer.js > bookmarklet.js