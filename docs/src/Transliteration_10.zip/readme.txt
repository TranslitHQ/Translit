Latin-Cyrillic (English-Russian) Transliteration Tool
=====================================================

This has been tested on Firefox 2 and Opera 9. Other browsers might work.
Internet Explorer 6 definitely won't.

If you're a user, pick one (or both):

example.html ....... Use this if you just want to transliterate from the Latin
                     to Cyrillic alphabet.
translit.user.js ... Install this as a Greasemonkey script to add a control
                     next to every text input to switch between Latin and
                     Cyrillic.
                     HINT: This translates well into a bookmarklet.

If you're a developer:

translit.js ........ Does the actual transliteration.
add-controls.js .... Puts the [cyr / lat] controls by text inputs.
build.sh ........... Concatenates files into the user script. Do not edit
                     translit.user.js directly; build.sh will overwrite it.
the rest ........... Used by build.sh.
